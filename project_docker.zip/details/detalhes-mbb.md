# Detalhes

**Tipografia principal** = Bricolage Grotesque (negrito)

**Tipografia de apoio** = Instrument Sans

# Paginas

- Estaticos
  - Artes estaticas separadas por grupos
- Carrosséis
  - Carrosséis de imagens com legenda, creditos (@ do criador), tags
- Stories
  - stories do instagram

# Pagina de links

- Titulo 
- subtitulo/tags
- links de contato (instagram, whatsapp, ??)
- links
  - Social media
  - Design
  - Portfólio - Design
  - Portfólio - Social media
  - Whatsapp
- vamos conversar (Card)
- Creditos pagina

# Paleta

- **Base** = #F5EDE3
- **Principal** = # D94270
- **Apoio quente** = #F28BAD
- **Acento vibrante** = #FF6B9D
- **Apoio Coral** = #F06C49
- **Contraste** = #2B1A1E
- **Neutro opcional** = #F4F4EF
